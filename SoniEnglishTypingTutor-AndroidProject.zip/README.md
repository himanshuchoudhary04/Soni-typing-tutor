# Soni English Typing Tutor — Android starter

This is an original Android implementation inspired by the requested English typing-tutor workflow.
It is NOT a conversion or extracted copy of the Windows EXE.

## Included
- English typing passage
- Start timer on first character
- WPM calculation
- Accuracy calculation
- Restart test
- Result when the passage is completed

## Build
Open this folder in Android Studio (Ladybug or newer), let Gradle sync, then:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated APK will normally appear under:
app/build/outputs/apk/debug/app-debug.apk
