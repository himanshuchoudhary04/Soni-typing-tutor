package com.soni.typingtutor

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {
    private lateinit var input: EditText
    private lateinit var timerView: TextView
    private lateinit var wpmView: TextView
    private lateinit var accuracyView: TextView
    private lateinit var resultView: TextView

    private val passage =
        "Practice makes typing faster and more accurate. Keep your fingers relaxed and focus on accuracy."

    private val handler = Handler(Looper.getMainLooper())
    private var started = false
    private var finished = false
    private var startMs = 0L
    private var elapsedSeconds = 0L

    private val ticker = object : Runnable {
        override fun run() {
            if (started && !finished) {
                elapsedSeconds = (System.currentTimeMillis() - startMs) / 1000
                timerView.text = "Time: ${elapsedSeconds}s"
                updateStats()
                handler.postDelayed(this, 500)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        timerView = findViewById(R.id.timer)
        wpmView = findViewById(R.id.wpm)
        accuracyView = findViewById(R.id.accuracy)
        resultView = findViewById(R.id.result)
        val restart = findViewById<Button>(R.id.restart)

        restart.setOnClickListener { resetTest() }

        input.addTextChangedListener(SimpleTextWatcher { text ->
            if (!started && text.isNotEmpty()) {
                started = true
                startMs = System.currentTimeMillis()
                handler.post(ticker)
            }
            updateStats()
            if (text.length >= passage.length && !finished) {
                finished = true
                updateStats()
                resultView.text =
                    "Test complete!\\nWPM: ${wpmView.text.toString().removePrefix("WPM: ")}\\n" +
                    "Accuracy: ${accuracyView.text.toString().removePrefix("Accuracy: ")}"
            }
        })
    }

    private fun updateStats() {
        val typed = input.text.toString()
        val correct = typed.indices.count { it < passage.length && typed[it] == passage[it] }
        val accuracy = if (typed.isEmpty()) 100.0 else correct * 100.0 / typed.length
        val minutes = ((System.currentTimeMillis() - startMs).coerceAtLeast(1)) / 60000.0
        val wpm = if (!started || typed.isEmpty()) 0.0 else (correct / 5.0) / minutes

        wpmView.text = "WPM: ${wpm.roundToInt()}"
        accuracyView.text = "Accuracy: ${accuracy.roundToInt()}%"
    }

    private fun resetTest() {
        handler.removeCallbacks(ticker)
        started = false
        finished = false
        startMs = 0L
        elapsedSeconds = 0L
        input.setText("")
        timerView.text = "Time: 0s"
        wpmView.text = "WPM: 0"
        accuracyView.text = "Accuracy: 100%"
        resultView.text = ""
        input.requestFocus()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }
}

private class SimpleTextWatcher(private val callback: (String) -> Unit) :
    android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        callback(s?.toString() ?: "")
    }
    override fun afterTextChanged(s: android.text.Editable?) = Unit
}
